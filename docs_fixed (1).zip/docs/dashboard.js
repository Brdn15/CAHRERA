// dashboard.js (module)
import { auth, db } from "./firebase-init.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-auth.js";
import { ref, onValue, push, update, remove } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-database.js";
import Chart from "https://cdn.jsdelivr.net/npm/chart.js";

onAuthStateChanged(auth, user => {
  if (!user) window.location = "index.html";
  else loadContacts(user.uid);
});

export function logout() {
  auth.signOut().then(() => window.location = "index.html");
}

export function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

let editingKey = null;
export function addContact() {
  const name = document.getElementById("contactName").value.trim();
  const number = document.getElementById("contactNumber").value.trim();
  if (!name || !number) return alert("Both fields required.");
  const uid = auth.currentUser.uid;
  push(ref(db, 'users/' + uid + '/contacts'), { name, number });
  document.getElementById("contactName").value = "";
  document.getElementById("contactNumber").value = "";
}

export function editContact(key, name, number) {
  editingKey = key;
  document.getElementById("editName").value = name;
  document.getElementById("editNumber").value = number;
  document.getElementById("editModal").style.display = "block";
}

export function closeModal() {
  document.getElementById("editModal").style.display = "none";
}

export function saveEdit() {
  const name = document.getElementById("editName").value.trim();
  const number = document.getElementById("editNumber").value.trim();
  if (!name || !number) return alert("Both fields required.");
  const uid = auth.currentUser.uid;
  update(ref(db, `users/${uid}/contacts/${editingKey}`), { name, number });
  closeModal();
}

export function loadContacts(uid) {
  const list = document.getElementById("contactList");
  const contactsRef = ref(db, 'users/' + uid + '/contacts');
  onValue(contactsRef, snapshot => {
    list.innerHTML = "";
    snapshot.forEach(child => {
      const { name, number } = child.val();
      const li = document.createElement("li");
      li.innerHTML = `
        ${name} - ${number}
        <button onclick="editContact('${child.key}', '${name}', '${number}')">✏️</button>
        <button onclick="remove(ref(db, 'users/${uid}/contacts/${child.key}'))">❌</button>`;
      list.appendChild(li);
    });
  });
}

// Chart simulation
const hrData = [], spo2Data = [], timeLabels = [];
const ctx = document.getElementById('healthChart').getContext('2d');
const healthChart = new Chart(ctx, {
  type: 'line',
  data: { labels: timeLabels, datasets: [
    { label: 'Heart Rate', data: hrData, borderColor: 'cyan', fill: false },
    { label: 'SpO₂', data: spo2Data, borderColor: 'magenta', fill: false }
  ]},
  options: { responsive: true }
});

setInterval(() => {
  const hr = Math.floor(60 + Math.random() * 30);
  const spo2 = Math.floor(95 + Math.random() * 5);
  const time = new Date().toLocaleTimeString();
  document.getElementById("hr").textContent = hr;
  document.getElementById("spo2").textContent = spo2;
  document.getElementById("status").textContent = (spo2 < 92 || hr > 100) ? "Alert" : "Normal";
  timeLabels.push(time); hrData.push(hr); spo2Data.push(spo2);
  if (timeLabels.length > 24) {
    timeLabels.shift(); hrData.shift(); spo2Data.shift();
  }
  healthChart.update();
}, 3600000);
