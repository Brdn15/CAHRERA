// signup.js
import { auth, db } from "./firebase-init.js";
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-auth.js";
import { ref, set } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-database.js";

document.getElementById("signupForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("newUsername").value;
  const password = document.getElementById("newPassword").value;
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await set(ref(db, 'users/' + cred.user.uid + '/contacts'), {});
    window.location.href = "dashboard.html";
  } catch (err) {
    alert("Signup failed: " + err.message);
  }
});
