// firebase-init.js (module)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyAlmA6SLnMhgWCW90VWxoTFT_9mkTQKFUA",
  authDomain: "cahrera-a3c5f.firebaseapp.com",
  databaseURL: "https://cahrera-a3c5f-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "cahrera-a3c5f",
  storageBucket: "cahrera-a3c5f.appspot.com",
  messagingSenderId: "998488673213",
  appId: "1:998488673213:web:d0b32a93599369e4e8e0d4"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
