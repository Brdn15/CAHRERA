
let hrData = [];
let spo2Data = [];
let timeLabels = [];
let editingIndex = null;

// AUTH
function signup(event) {
  event.preventDefault();
  const user = document.getElementById("newUsername").value;
  const pass = document.getElementById("newPassword").value;
  localStorage.setItem("user", JSON.stringify({ user, pass }));
  alert("Account created!");
  window.location.href = "index.html";
}

function login(event) {
  event.preventDefault();
  const inputUser = document.getElementById("username").value;
  const inputPass = document.getElementById("password").value;
  const stored = JSON.parse(localStorage.getItem("user"));

  if (stored && stored.user === inputUser && stored.pass === inputPass) {
    window.location.href = "dashboard.html";
  } else {
    alert("Invalid credentials.");
  }
}

function logout() {
  window.location.href = "index.html";
}

// DARK MODE
function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

// CONTACTS
function addContact() {
  const name = document.getElementById("contactName").value;
  const number = document.getElementById("contactNumber").value;
  if (!name || !number) return alert("Both fields are required.");

  const list = document.getElementById("contactList");
  const li = document.createElement("li");
  li.innerHTML = `${name} - ${number} 
    <button onclick="editContact(this)">✏️</button> 
    <button onclick="this.parentElement.remove()">❌</button>`;
  list.appendChild(li);

  document.getElementById("contactName").value = "";
  document.getElementById("contactNumber").value = "";
}

function editContact(button) {
  const li = button.parentElement;
  editingIndex = Array.from(li.parentNode.children).indexOf(li);
  const [name, number] = li.textContent.split(" - ");
  document.getElementById("editName").value = name.trim();
  document.getElementById("editNumber").value = number.trim();
  document.getElementById("editModal").style.display = "block";
}

function closeModal() {
  document.getElementById("editModal").style.display = "none";
}

function saveEdit() {
  const newName = document.getElementById("editName").value;
  const newNumber = document.getElementById("editNumber").value;
  const li = document.querySelectorAll("#contactList li")[editingIndex];
  li.innerHTML = `${newName} - ${newNumber} 
    <button onclick="editContact(this)">✏️</button> 
    <button onclick="this.parentElement.remove()">❌</button>`;
  closeModal();
}

// CHART SETUP
const ctx = document.getElementById('healthChart').getContext('2d');
const healthChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: timeLabels,
    datasets: [
      {
        label: 'Heart Rate (BPM)',
        data: hrData,
        borderColor: 'rgba(75, 192, 192, 1)',
        fill: false,
      },
      {
        label: 'SpO₂ (%)',
        data: spo2Data,
        borderColor: 'rgba(255, 99, 132, 1)',
        fill: false,
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        title: {
          display: true,
          text: 'Time'
        }
      },
      y: {
        title: {
          display: true,
          text: 'Readings'
        }
      }
    }
  }
});

// Update every simulated hour (5 sec)
setInterval(() => {
  const hr = Math.floor(60 + Math.random() * 30);
  const spo2 = Math.floor(95 + Math.random() * 5);
  const time = new Date().toLocaleTimeString();

  document.getElementById("hr").textContent = hr;
  document.getElementById("spo2").textContent = spo2;
  document.getElementById("status").textContent = (spo2 < 92 || hr > 100) ? "Alert" : "Normal";
  document.getElementById("analysisText").textContent = `Today, avg HR: ${hr} BPM, SpO₂: ${spo2}%`;

  hrData.push(hr);
  spo2Data.push(spo2);
  timeLabels.push(time);

  if (hrData.length > 24) {
    hrData.shift();
    spo2Data.shift();
    timeLabels.shift();
  }

  healthChart.update();
}, 5000);

